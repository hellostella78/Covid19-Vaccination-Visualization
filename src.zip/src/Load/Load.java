package Load;

//import java.awt.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.io.BufferedReader;

public class Load {

	public static void main(String[] args) {
		File csvFile = new File("C:\\Users\\Public\\temp\\TeamProjectRandomData - 10People");
		if (csvFile.isFile()) {
		    // create BufferedReader and read data from csv
			BufferedReader csvReader = new BufferedReader(new FileReader("C:\\Users\\Public\\temp\\TeamProjectRandomData - 10People"));
			String row = new String();
			while ((row = csvReader.readLine()) != null) {
			    String[] data = row.split(",");
			    // do something with the data
			}
			csvReader.close();
		}
		
	}
}
